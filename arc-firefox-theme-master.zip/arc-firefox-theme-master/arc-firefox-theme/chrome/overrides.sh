#!/bin/bash

cp browser/feeds/feedIcon.png browser/feeds/audioFeedIcon.png
cp browser/feeds/feedIcon16.png browser/feeds/audioFeedIcon16.png
cp browser/feeds/feedIcon.png browser/feeds/videoFeedIcon.png
cp browser/feeds/feedIcon16.png browser/feeds/videoFeedIcon16.png

cp global/arrow/arrow-lft.gif global/arrow/arrow-lft-hov.gif
cp global/arrow/arrow-rit.gif global/arrow/arrow-rit-hov.gif

cp mozapps/extensions/dictionaryGeneric.png mozapps/extensions/category-dictionaries.png
cp mozapps/extensions/experimentGeneric.png mozapps/extensions/category-experiments.png
cp mozapps/extensions/extensionGeneric.svg mozapps/extensions/category-extensions.svg
cp mozapps/extensions/localeGeneric.png mozapps/extensions/category-languages.png
cp mozapps/extensions/themeGeneric.png mozapps/extensions/category-themes.png

cp mozapps/passwordmgr/key-16.png mozapps/passwordmgr/key.png

cp mozapps/plugins/pluginGeneric-16.png mozapps/plugins/notifyPluginCrashed.png
cp mozapps/plugins/pluginGeneric-16.png mozapps/plugins/notifyPluginGeneric.png
